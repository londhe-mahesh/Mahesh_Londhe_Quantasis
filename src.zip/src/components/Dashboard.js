import React from 'react'
import UserList
 from './UserList'
function Dashboard(){
    return(
            <UserList></UserList>
    )
}
export default Dashboard